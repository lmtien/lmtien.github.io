# Agent Autoloop: local decision demo

Tested on Linux with Node 24.22.1 and Agent Autoloop v1.8.3 (commit 1bd9aa2549d9506053c778c6fef9f8a68b78d5bf). Requires Node 24+, Git. POSIX shell commands below. This is a deterministic command adapter, not an LLM, and does not validate Codex/Claude session resumption. No model account is required for this demo.

In a fresh extracted `autoloop-demo` folder:

    git clone --depth 1 --branch v1.8.3 https://github.com/KKKKhazix/agent-autoloop.git autoloop-src
    node setup.mjs
    export AGENT_AUTOLOOP_HOME="$PWD/.autoloop-demo"
    node autoloop-src/bin/agent-autoloop.ts check
    node autoloop-src/bin/agent-autoloop.ts up

Keep that terminal open. In a second terminal in the same folder:

    export AGENT_AUTOLOOP_HOME="$PWD/.autoloop-demo"
    node autoloop-src/bin/agent-autoloop.ts emit demo.review --dry-run
    node autoloop-src/bin/agent-autoloop.ts emit demo.review
    node autoloop-src/bin/agent-autoloop.ts status

Wait for the decision card. Before answering, `reviewed.txt` must not exist. Use the actual card number from status (normally 1 in this new data directory):

    node autoloop-src/bin/agent-autoloop.ts answer 1 2
    node autoloop-src/bin/agent-autoloop.ts status

Wait until run 2 finishes, then inspect `reviewed.txt`. `why 2` shows the timeline. Option 1 keeps the draft and writes no marker; a fresh extracted folder is simplest for repeating this demonstration. Stop this foreground instance with Ctrl+C in the first terminal. The demo does not install a system service. Port 3388 must be unused; change it in setup.mjs before setup if necessary.

The setup script creates only a fresh .autoloop-demo folder, disables notification channels, and uses a local script. It does not harden that script's operating-system permissions. Never package the generated data directory: it contains keys and private runtime state. These files are not included in this download.

The included CLI evidence is from the author's first completed run, using the official installer with --no-service and equivalent local configuration. The published setup helper was separately exercised with the same two-turn outcome. The original CLI is Chinese; `等你` means waiting for you, `在跑` running, `排队` queued, and `做完` completed. Token and fee values were not reported, not zero.
