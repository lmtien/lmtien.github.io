import { readFileSync, writeFileSync } from 'node:fs';
const context = JSON.parse(readFileSync(process.env.AGENT_AUTOLOOP_CONTEXT, 'utf8'));
const draft = readFileSync('draft.txt', 'utf8');
if (!draft.trim()) throw new Error('Draft is empty.');
const answer = context.answers.find(a => a.title === 'Review the local draft?');
if (!answer) {
  console.log('Draft inspected. Waiting for a local decision.');
  console.log('```agent-autoloop\n' + JSON.stringify({ask:[{
    title:'Review the local draft?', text:'This demo only writes reviewed.txt in the demo folder.',
    options:['Keep draft','Mark reviewed'], key:'draft-review', about:'Finish the local demo after the decision.'
  }]}) + '\n```');
} else if (answer.chosen === 'Mark reviewed') {
  writeFileSync('reviewed.txt', 'Reviewed after an explicit local answer.\n');
  console.log('Done: reviewed.txt written after Mark reviewed.');
} else {
  console.log('Done: kept the draft; no review marker written.');
}
