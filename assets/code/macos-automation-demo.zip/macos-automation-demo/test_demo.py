import tempfile, unittest
from pathlib import Path
from demo import Processor, parse_report
class Checks(unittest.TestCase):
    def test_decimal_total(self):
        self.assertEqual(parse_report(b'item,amount\na,6.25\nb,3.75\n'), '2 rows; total 10.00\n')
    def test_wrong_schema_rejected(self):
        with self.assertRaises(ValueError): parse_report(b'other,value\nx,1\n')
    def test_deduplication_survives_reopen(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=Processor(root);f=p.inbox/'a.csv';f.write_bytes(b'item,amount\na,1\n')
            self.assertEqual(p.handle(f),'processed');p.db.close();p=Processor(root)
            self.assertEqual(p.handle(f),'duplicate');p.db.close()
    def test_partial_files_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Processor(Path(tmp));f=p.inbox/'a.part';f.write_text('partial')
            self.assertEqual(p.handle(f),'ignored');p.db.close()
if __name__ == '__main__': unittest.main()
