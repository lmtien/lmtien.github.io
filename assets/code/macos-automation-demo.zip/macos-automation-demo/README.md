# Website → file watcher → local app handoff

Original local fixture. Tested on Linux with Python 3.12, watchdog 7.1.0, Playwright 1.65.1 and system Chromium. macOS native actions and the FSEvents backend were not executed in the author's environment.

In a fresh extracted folder:

    python3 -m venv .venv
    source .venv/bin/activate
    python -m pip install -r requirements.txt
    python -m playwright install chromium
    python -m unittest -v test_demo.py
    python demo.py

The author's Linux run used `DEMO_CHROMIUM=/usr/bin/chromium python demo.py`. If that variable is absent, Playwright uses its own installed Chromium. The exact bundled-browser install and native macOS integration were not tested here.

The demo starts an HTTP server on a loopback-only ephemeral port, starts a watcher, exports two identical CSVs from the local fixture, and waits up to ten seconds after browser work for two finalized paths. Browser operations have Playwright's own timeouts. It then shuts down the browser, watcher and server. It is a bounded integration demo, not a permanently installed background service.

Expected first-run output:

    SUMMARY: 2 rows; total 10.00
    EVENT RESULTS: processed, duplicate
    NATIVE ACTIONS: not run (use --mac-actions on macOS)

Inspect run/summary.txt, run/evidence.json and run/browser.png. The seen.sqlite database persists hashes. Repeating on the same state returns duplicate, duplicate and preserves the summary. Unit tests cover decimal totals, schema rejection, partial-file filtering and deduplication after reopening the database.

On macOS only, explicitly opt in to showing a notification and opening the summary in TextEdit:

    python demo.py --mac-actions

This path calls osascript with a fixed script file and an argv message, then open -a TextEdit with a file path. It is source-reviewed against Apple's documentation, not native-tested. Notifications depend on your Mac's settings; opening the application is visible. A failure raises an error. evidence.json records native actions as requested, not verified successful.

The browser saves a download as .part then renames it to .csv only after completion. This protocol is intentional: a .csv written in-place by another producer may still be incomplete. Content hashes suppress repeated processing of identical bytes; they do not guarantee exactly-once notifications or crash-safe external actions. The output write and database commit are separate operations. Real long-running use needs startup reconciliation, bounded retries, logs and action-specific idempotency.

No personal account or external website is accessed. The fixture report contains synthetic data. No downloaded file is executed. The watcher is limited to its own run/inbox directory. Keep run output out of version control if you adapt it to private data.
