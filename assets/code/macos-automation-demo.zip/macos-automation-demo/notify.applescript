on run argv
    display notification (item 1 of argv) with title "Local report ready"
end run
