import argparse, csv, functools, hashlib, http.server, io, json, os, platform, queue, sqlite3, subprocess, threading, time
from pathlib import Path
from decimal import Decimal
from playwright.sync_api import sync_playwright
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer
ROOT = Path(__file__).resolve().parent

def parse_report(data):
    reader = csv.DictReader(io.StringIO(data.decode('utf-8')))
    if reader.fieldnames != ['item', 'amount']: raise ValueError('Expected item,amount columns')
    rows = list(reader)
    if not rows: raise ValueError('Empty report')
    amounts = [Decimal(row['amount']) for row in rows]
    if not all(v.is_finite() for v in amounts): raise ValueError('Non-finite amount')
    return f'{len(rows)} rows; total {sum(amounts, Decimal(0)):.2f}\n'

class Processor:
    def __init__(self, state):
        self.state = state; self.inbox = state / 'inbox'
        self.inbox.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(state / 'seen.sqlite')
        self.db.execute('CREATE TABLE IF NOT EXISTS seen (digest TEXT PRIMARY KEY)')
    def handle(self, path):
        path = Path(path)
        if path.suffix != '.csv' or path.resolve().parent != self.inbox.resolve(): return 'ignored'
        data = path.read_bytes(); digest = hashlib.sha256(data).hexdigest()
        if self.db.execute('SELECT 1 FROM seen WHERE digest=?', (digest,)).fetchone(): return 'duplicate'
        summary = parse_report(data)
        tmp = self.state / 'summary.tmp'; tmp.write_text(summary); tmp.replace(self.state / 'summary.txt')
        self.db.execute('INSERT INTO seen VALUES (?)', (digest,)); self.db.commit()
        return 'processed'

class Events(FileSystemEventHandler):
    def __init__(self, pending): self.pending = pending
    def on_created(self, event):
        if not event.is_directory: self.pending.put(event.src_path)
    def on_modified(self, event):
        if not event.is_directory: self.pending.put(event.src_path)
    def on_moved(self, event):
        if not event.is_directory: self.pending.put(event.dest_path)

def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--mac-actions', action='store_true'); args = parser.parse_args()
    if args.mac_actions and platform.system() != 'Darwin': parser.error('--mac-actions requires macOS')
    state = ROOT / 'run'; processor = Processor(state); pending = queue.Queue(); observer = Observer()
    observer.schedule(Events(pending), str(processor.inbox), recursive=False)
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT / 'site'))
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start(); observer.start()
    try:
        launch = {'headless': True}
        if os.environ.get('DEMO_CHROMIUM'): launch['executable_path'] = os.environ['DEMO_CHROMIUM']
        with sync_playwright() as pw:
            browser = pw.chromium.launch(**launch)
            try:
                page = browser.new_page(viewport={'width':1200, 'height':850})
                page.goto(f'http://127.0.0.1:{server.server_port}/', wait_until='load')
                for name in ['report-a', 'report-b']:
                    with page.expect_download() as info: page.get_by_role('button', name='Export CSV').click()
                    partial = processor.inbox / f'{name}.part'; info.value.save_as(partial)
                    partial.replace(processor.inbox / f'{name}.csv')
                page.screenshot(path=str(state / 'browser.png'), full_page=True)
            finally: browser.close()
        deadline = time.monotonic() + 10; outcomes = []; handled = set()
        while time.monotonic() < deadline and len(outcomes) < 2:
            try:
                path = pending.get(timeout=.5)
                if path in handled: continue
                result = processor.handle(path)
                if result != 'ignored':
                    handled.add(path)
                    outcomes.append(result)
            except queue.Empty: pass
        if len(outcomes) != 2:
            raise RuntimeError(f'Expected two finalized CSV paths, got {outcomes}')
        summary = (state / 'summary.txt').read_text().strip()
        print('SUMMARY:', summary); print('EVENT RESULTS:', ', '.join(outcomes))
        evidence = {'platform':platform.system(), 'summary':summary, 'outcomes':outcomes,
                    'native_actions':'requested' if args.mac_actions else 'not run'}
        (state / 'evidence.json').write_text(json.dumps(evidence, indent=2)+'\n')
        if args.mac_actions:
            subprocess.run(['/usr/bin/osascript', str(ROOT / 'notify.applescript'), summary], check=True, timeout=15)
            subprocess.run(['/usr/bin/open', '-a', 'TextEdit', str(state / 'summary.txt')], check=True, timeout=15)
        else: print('NATIVE ACTIONS: not run (use --mac-actions on macOS)')
    finally:
        observer.stop(); observer.join(); server.shutdown(); server.server_close(); processor.db.close()
if __name__ == '__main__': main()
