---
name: jekyll-publish-review
description: Use when reviewing a Jekyll Markdown post for publication readiness, especially scheduled dates and local image references.
---

# Jekyll publication review

This is a read-only source review, not a build or deployment check.

1. Read the post frontmatter and `_config.yml`.
2. Compare the full post timestamp, including its UTC offset, with the supplied current instant. If no instant is supplied, obtain the current time. If the date has no offset, inspect the site timezone; report uncertainty rather than guessing.
3. With `future: false` (Jekyll's default), flag a later post timestamp as excluded from the build.
4. Resolve root-relative local Markdown image paths from the site source root. Verify the files exist; report each missing path. Do not fetch external images. This review does not cover Liquid-generated URLs or every HTML image syntax.
5. Return these sections: Verdict, Evidence, Not checked. Evidence includes the UTC comparison and each local image path with its existence result. Not checked states that no build, browser rendering, or deployment was tested.

For unrelated tasks, leave the workflow unused. Do not edit or publish files during review.
