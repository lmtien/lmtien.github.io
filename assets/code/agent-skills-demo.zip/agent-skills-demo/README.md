# Agent skill publication-review demo

Requires an agent host supporting local Agent Skills (installation below is for Codex).
No Python package, browser, API key, or remote skill installer is needed for these fixture files. The agent itself needs its normal runtime/authentication.

1. Unzip and enter `agent-skills-demo/fixture`.
2. Run a fresh agent session with the text in `../task.txt`. Save its response outside this folder.
3. Install the skill:

   mkdir -p .agents/skills/jekyll-publish-review
   cp ../skill/SKILL.md .agents/skills/jekyll-publish-review/SKILL.md

4. Start another fresh session. Use the same task prefixed with `$jekyll-publish-review`.
5. Compare detection of the future timestamp (17:00Z > 08:30Z) and missing `/assets/release-flow.svg`, plus whether the output states what was not checked.

The simulated instant is intentional. Use it even when repeating this experiment on another date. The fixture is deliberately incomplete; do not deploy it.

Included evidence is from one fresh subagent per condition in the same managed Codex session, with the parent model inherited. The treatment was explicitly told to read the skill file. This tests applying the instructions, not automatic discovery. Other runtime instructions were not removed. Agent outputs have been transcribed with absolute fixture paths shortened. No timing, cost, or general quality claim is supported by this sample.
