# Try, hint, explain, retry

An original deterministic browser worksheet. It is not an AI tutor and does not collect or transmit responses. No study participants or child learning outcomes were measured.

Run `python3 -m http.server 8000 --bind 127.0.0.1` in this folder and open http://127.0.0.1:8000. Python 3 is the only server requirement; the page is plain HTML/CSS/JavaScript.

Try 3x + 5 = 20. Write an attempt, request a fixed hint, explain a step, and enter an answer. The second problem is 4x + 3 = 19. Answers are 5 and 4. The script checks answers numerically, not the explanation. A learner can bypass the effort gate by entering arbitrary text. This illustrates an interface flow, not an enforceable pedagogy or validated learning intervention.

Browser check in the author's environment: Playwright with /usr/bin/chromium. Checked: empty-attempt gate; hint without final answer; incorrect-answer feedback; second problem unlocked after correct first answer; hint hidden on transition; correct transfer answer; no document overflow at 390px width. This does not evaluate retention or independent student behavior.
